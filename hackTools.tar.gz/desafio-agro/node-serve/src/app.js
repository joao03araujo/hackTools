const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')

const app = express()
const corsOptions = { origin: '*', optionsSuccessStatus: 200 }

app.use(cors(corsOptions))
app.use(express.json())
app.use(bodyParser.urlencoded({ extended: false }));

const quests = []

app.post('/', (req, res) => {
    const { usuario, primeiraPergunta, segundaPergunta, titulo, data, latitude, longitude } = req.body
    quests.push({ primeiraPergunta, segundaPergunta, titulo, data, usuario, latitude, longitude })
    res.json({ message: `Questionário criado com sucesso pelo usuário: ${usuario}`})
})

app.get('/', (req, res) => {
    res.json(quests)
})

app.post('/resposta', (req, res) => {
    const { usuario, primeiraPergunta, segundaPergunta, titulo, data, latitude, longitude, resposta1, resposta2 } = req.body
    quests.push({ primeiraPergunta, segundaPergunta, titulo, data, usuario, latitude, longitude, resposta1, resposta2 })
    res.json({ message: `Respostas salavas com sucesso pelo usuário: ${usuario}`})
})

app.get('/resposta', (req, res) => {
    res.json(quests)
})


app.listen(3000)